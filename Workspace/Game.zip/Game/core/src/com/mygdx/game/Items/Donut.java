package com.mygdx.game.Items;

import com.badlogic.gdx.graphics.Texture;

public class Donut extends Food{
	
	
	public Donut(float x, float y){
		super(x,y);
		nutrition = 5;
		rarity = 5;
		img = new Texture("Items/Food/donut.png");
		//sprite = new Sprite(img);
		//sprite.setPosition(posX, posY);
	}
	

}