package com.mygdx.game.Character;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Shape2D;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.Collisions;

public class Character {
	//Debug: Gdx.app.log("Character", "Text");
	Sprite sprite;
	
	public static ArrayList<Character> characters = new ArrayList<Character>();
	public int char_index;
	
	public static int tilesize = 32;
	
	public int health = 100;
	public float x,y;
	
	public Texture tex;
	
	private Collisions collider;
	public boolean has_collider = false;
	
	
	public Character(float x, float y) {
		this.x = x;
		this.y = y;
		
		collider = new Collisions();
		setCollider(32, 32);
	}

	public Character(Texture tex) {
		Gdx.app.log("Character","Pos not set");
		this.x = 0;
		this.y = 0;
		this.tex = tex;
		
		collider = new Collisions();
	}
	
	//Can be called every frame if designated in map
	public void update(){

	}
	
	public float distance(float x1, float y1, float x2, float y2){
		return (float) Math.sqrt(((x2 - x1) * (x2 - x2)) + ((y2 - y1) * (y2 - y1)));
	}
	
	public int addCharacter(Character c){
		characters.add(c);
		return characters.size() - 1;
	}
	
	public void setCollider(){
		collider.setRectangle(x, y, 10, 10);
		has_collider = true;
	}
	
	public void setCollider(float width, float height){
		collider.setRectangle(x, y, width, height);
		has_collider = true;
	}
	
	public void setCollider(float radius){
		collider.setCircle(x, y, radius);
		has_collider = true;
	}
	
	public void setCollider(Shape2D shape){
		try{
			if(((Circle) shape).radius != 0){
				collider.setCircle(shape);
			}
		}
		catch (java.lang.ClassCastException e){
			collider.setRectangle(shape);
		}
		has_collider = true;
	}
	
	public Shape2D getCollider(){
		return collider.getCollider();
	}
	
	public void setPosition(float x, float y){
		this.x = x;
		this.y = y;
		if(has_collider){
			collider.setPosition(x, y);
		}
		else{
			Gdx.app.log("Character", "No Collider");
		}
	}
	
	public void translate(float x, float y){
		this.x += x;
		this.y += y;
		if(has_collider){
			collider.setPosition(this.x, this.y);
		}
		else{
			Gdx.app.log("Character", "No Collider");
		}
	}
	
	public Vector2 getPosition(){
		return new Vector2(x,y);
	}
	
	public boolean isColliding(Shape2D other){
		return collider.isColliding(other);
	}

}
